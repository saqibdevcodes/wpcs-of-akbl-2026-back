import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
/**
 * Model Excel
 *
 */
export type ExcelModel = runtime.Types.Result.DefaultSelection<Prisma.$ExcelPayload>;
export type AggregateExcel = {
    _count: ExcelCountAggregateOutputType | null;
    _avg: ExcelAvgAggregateOutputType | null;
    _sum: ExcelSumAggregateOutputType | null;
    _min: ExcelMinAggregateOutputType | null;
    _max: ExcelMaxAggregateOutputType | null;
};
export type ExcelAvgAggregateOutputType = {
    id: number | null;
    gender: number | null;
    age: number | null;
    region: number | null;
    department: number | null;
    empTenure: number | null;
    overallExperinceSatifyQ2: number | null;
    overallExperinceCompleteQ3: number | null;
    overallExperinceRecommentQ4: number | null;
};
export type ExcelSumAggregateOutputType = {
    id: number | null;
    gender: number | null;
    age: number | null;
    region: number | null;
    department: number | null;
    empTenure: number | null;
    overallExperinceSatifyQ2: number | null;
    overallExperinceCompleteQ3: number | null;
    overallExperinceRecommentQ4: number | null;
};
export type ExcelMinAggregateOutputType = {
    id: number | null;
    gender: number | null;
    age: number | null;
    region: number | null;
    department: number | null;
    empTenure: number | null;
    overallExperinceSatifyQ2: number | null;
    overallExperinceCompleteQ3: number | null;
    overallExperinceRecommentQ4: number | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type ExcelMaxAggregateOutputType = {
    id: number | null;
    gender: number | null;
    age: number | null;
    region: number | null;
    department: number | null;
    empTenure: number | null;
    overallExperinceSatifyQ2: number | null;
    overallExperinceCompleteQ3: number | null;
    overallExperinceRecommentQ4: number | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type ExcelCountAggregateOutputType = {
    id: number;
    gender: number;
    age: number;
    region: number;
    department: number;
    empTenure: number;
    overallExperinceSatifyQ2: number;
    overallExperinceCompleteQ3: number;
    overallExperinceRecommentQ4: number;
    createdAt: number;
    updatedAt: number;
    _all: number;
};
export type ExcelAvgAggregateInputType = {
    id?: true;
    gender?: true;
    age?: true;
    region?: true;
    department?: true;
    empTenure?: true;
    overallExperinceSatifyQ2?: true;
    overallExperinceCompleteQ3?: true;
    overallExperinceRecommentQ4?: true;
};
export type ExcelSumAggregateInputType = {
    id?: true;
    gender?: true;
    age?: true;
    region?: true;
    department?: true;
    empTenure?: true;
    overallExperinceSatifyQ2?: true;
    overallExperinceCompleteQ3?: true;
    overallExperinceRecommentQ4?: true;
};
export type ExcelMinAggregateInputType = {
    id?: true;
    gender?: true;
    age?: true;
    region?: true;
    department?: true;
    empTenure?: true;
    overallExperinceSatifyQ2?: true;
    overallExperinceCompleteQ3?: true;
    overallExperinceRecommentQ4?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type ExcelMaxAggregateInputType = {
    id?: true;
    gender?: true;
    age?: true;
    region?: true;
    department?: true;
    empTenure?: true;
    overallExperinceSatifyQ2?: true;
    overallExperinceCompleteQ3?: true;
    overallExperinceRecommentQ4?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type ExcelCountAggregateInputType = {
    id?: true;
    gender?: true;
    age?: true;
    region?: true;
    department?: true;
    empTenure?: true;
    overallExperinceSatifyQ2?: true;
    overallExperinceCompleteQ3?: true;
    overallExperinceRecommentQ4?: true;
    createdAt?: true;
    updatedAt?: true;
    _all?: true;
};
export type ExcelAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which Excel to aggregate.
     */
    where?: Prisma.ExcelWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Excels to fetch.
     */
    orderBy?: Prisma.ExcelOrderByWithRelationInput | Prisma.ExcelOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the start position
     */
    cursor?: Prisma.ExcelWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Excels from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Excels.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Count returned Excels
    **/
    _count?: true | ExcelCountAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to average
    **/
    _avg?: ExcelAvgAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to sum
    **/
    _sum?: ExcelSumAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the minimum value
    **/
    _min?: ExcelMinAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the maximum value
    **/
    _max?: ExcelMaxAggregateInputType;
};
export type GetExcelAggregateType<T extends ExcelAggregateArgs> = {
    [P in keyof T & keyof AggregateExcel]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateExcel[P]> : Prisma.GetScalarType<T[P], AggregateExcel[P]>;
};
export type ExcelGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.ExcelWhereInput;
    orderBy?: Prisma.ExcelOrderByWithAggregationInput | Prisma.ExcelOrderByWithAggregationInput[];
    by: Prisma.ExcelScalarFieldEnum[] | Prisma.ExcelScalarFieldEnum;
    having?: Prisma.ExcelScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: ExcelCountAggregateInputType | true;
    _avg?: ExcelAvgAggregateInputType;
    _sum?: ExcelSumAggregateInputType;
    _min?: ExcelMinAggregateInputType;
    _max?: ExcelMaxAggregateInputType;
};
export type ExcelGroupByOutputType = {
    id: number;
    gender: number;
    age: number;
    region: number;
    department: number;
    empTenure: number;
    overallExperinceSatifyQ2: number;
    overallExperinceCompleteQ3: number;
    overallExperinceRecommentQ4: number;
    createdAt: Date;
    updatedAt: Date;
    _count: ExcelCountAggregateOutputType | null;
    _avg: ExcelAvgAggregateOutputType | null;
    _sum: ExcelSumAggregateOutputType | null;
    _min: ExcelMinAggregateOutputType | null;
    _max: ExcelMaxAggregateOutputType | null;
};
export type GetExcelGroupByPayload<T extends ExcelGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<ExcelGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof ExcelGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], ExcelGroupByOutputType[P]> : Prisma.GetScalarType<T[P], ExcelGroupByOutputType[P]>;
}>>;
export type ExcelWhereInput = {
    AND?: Prisma.ExcelWhereInput | Prisma.ExcelWhereInput[];
    OR?: Prisma.ExcelWhereInput[];
    NOT?: Prisma.ExcelWhereInput | Prisma.ExcelWhereInput[];
    id?: Prisma.IntFilter<"Excel"> | number;
    gender?: Prisma.IntFilter<"Excel"> | number;
    age?: Prisma.IntFilter<"Excel"> | number;
    region?: Prisma.IntFilter<"Excel"> | number;
    department?: Prisma.IntFilter<"Excel"> | number;
    empTenure?: Prisma.IntFilter<"Excel"> | number;
    overallExperinceSatifyQ2?: Prisma.IntFilter<"Excel"> | number;
    overallExperinceCompleteQ3?: Prisma.IntFilter<"Excel"> | number;
    overallExperinceRecommentQ4?: Prisma.IntFilter<"Excel"> | number;
    createdAt?: Prisma.DateTimeFilter<"Excel"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"Excel"> | Date | string;
};
export type ExcelOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type ExcelWhereUniqueInput = Prisma.AtLeast<{
    id?: number;
    AND?: Prisma.ExcelWhereInput | Prisma.ExcelWhereInput[];
    OR?: Prisma.ExcelWhereInput[];
    NOT?: Prisma.ExcelWhereInput | Prisma.ExcelWhereInput[];
    gender?: Prisma.IntFilter<"Excel"> | number;
    age?: Prisma.IntFilter<"Excel"> | number;
    region?: Prisma.IntFilter<"Excel"> | number;
    department?: Prisma.IntFilter<"Excel"> | number;
    empTenure?: Prisma.IntFilter<"Excel"> | number;
    overallExperinceSatifyQ2?: Prisma.IntFilter<"Excel"> | number;
    overallExperinceCompleteQ3?: Prisma.IntFilter<"Excel"> | number;
    overallExperinceRecommentQ4?: Prisma.IntFilter<"Excel"> | number;
    createdAt?: Prisma.DateTimeFilter<"Excel"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"Excel"> | Date | string;
}, "id">;
export type ExcelOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    _count?: Prisma.ExcelCountOrderByAggregateInput;
    _avg?: Prisma.ExcelAvgOrderByAggregateInput;
    _max?: Prisma.ExcelMaxOrderByAggregateInput;
    _min?: Prisma.ExcelMinOrderByAggregateInput;
    _sum?: Prisma.ExcelSumOrderByAggregateInput;
};
export type ExcelScalarWhereWithAggregatesInput = {
    AND?: Prisma.ExcelScalarWhereWithAggregatesInput | Prisma.ExcelScalarWhereWithAggregatesInput[];
    OR?: Prisma.ExcelScalarWhereWithAggregatesInput[];
    NOT?: Prisma.ExcelScalarWhereWithAggregatesInput | Prisma.ExcelScalarWhereWithAggregatesInput[];
    id?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    gender?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    age?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    region?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    department?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    empTenure?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    overallExperinceSatifyQ2?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    overallExperinceCompleteQ3?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    overallExperinceRecommentQ4?: Prisma.IntWithAggregatesFilter<"Excel"> | number;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"Excel"> | Date | string;
    updatedAt?: Prisma.DateTimeWithAggregatesFilter<"Excel"> | Date | string;
};
export type ExcelCreateInput = {
    gender: number;
    age: number;
    region: number;
    department: number;
    empTenure: number;
    overallExperinceSatifyQ2: number;
    overallExperinceCompleteQ3: number;
    overallExperinceRecommentQ4: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type ExcelUncheckedCreateInput = {
    id?: number;
    gender: number;
    age: number;
    region: number;
    department: number;
    empTenure: number;
    overallExperinceSatifyQ2: number;
    overallExperinceCompleteQ3: number;
    overallExperinceRecommentQ4: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type ExcelUpdateInput = {
    gender?: Prisma.IntFieldUpdateOperationsInput | number;
    age?: Prisma.IntFieldUpdateOperationsInput | number;
    region?: Prisma.IntFieldUpdateOperationsInput | number;
    department?: Prisma.IntFieldUpdateOperationsInput | number;
    empTenure?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceSatifyQ2?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceCompleteQ3?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceRecommentQ4?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type ExcelUncheckedUpdateInput = {
    id?: Prisma.IntFieldUpdateOperationsInput | number;
    gender?: Prisma.IntFieldUpdateOperationsInput | number;
    age?: Prisma.IntFieldUpdateOperationsInput | number;
    region?: Prisma.IntFieldUpdateOperationsInput | number;
    department?: Prisma.IntFieldUpdateOperationsInput | number;
    empTenure?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceSatifyQ2?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceCompleteQ3?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceRecommentQ4?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type ExcelCreateManyInput = {
    id?: number;
    gender: number;
    age: number;
    region: number;
    department: number;
    empTenure: number;
    overallExperinceSatifyQ2: number;
    overallExperinceCompleteQ3: number;
    overallExperinceRecommentQ4: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type ExcelUpdateManyMutationInput = {
    gender?: Prisma.IntFieldUpdateOperationsInput | number;
    age?: Prisma.IntFieldUpdateOperationsInput | number;
    region?: Prisma.IntFieldUpdateOperationsInput | number;
    department?: Prisma.IntFieldUpdateOperationsInput | number;
    empTenure?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceSatifyQ2?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceCompleteQ3?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceRecommentQ4?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type ExcelUncheckedUpdateManyInput = {
    id?: Prisma.IntFieldUpdateOperationsInput | number;
    gender?: Prisma.IntFieldUpdateOperationsInput | number;
    age?: Prisma.IntFieldUpdateOperationsInput | number;
    region?: Prisma.IntFieldUpdateOperationsInput | number;
    department?: Prisma.IntFieldUpdateOperationsInput | number;
    empTenure?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceSatifyQ2?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceCompleteQ3?: Prisma.IntFieldUpdateOperationsInput | number;
    overallExperinceRecommentQ4?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type ExcelCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type ExcelAvgOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
};
export type ExcelMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type ExcelMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type ExcelSumOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    gender?: Prisma.SortOrder;
    age?: Prisma.SortOrder;
    region?: Prisma.SortOrder;
    department?: Prisma.SortOrder;
    empTenure?: Prisma.SortOrder;
    overallExperinceSatifyQ2?: Prisma.SortOrder;
    overallExperinceCompleteQ3?: Prisma.SortOrder;
    overallExperinceRecommentQ4?: Prisma.SortOrder;
};
export type ExcelSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    gender?: boolean;
    age?: boolean;
    region?: boolean;
    department?: boolean;
    empTenure?: boolean;
    overallExperinceSatifyQ2?: boolean;
    overallExperinceCompleteQ3?: boolean;
    overallExperinceRecommentQ4?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
}, ExtArgs["result"]["excel"]>;
export type ExcelSelectScalar = {
    id?: boolean;
    gender?: boolean;
    age?: boolean;
    region?: boolean;
    department?: boolean;
    empTenure?: boolean;
    overallExperinceSatifyQ2?: boolean;
    overallExperinceCompleteQ3?: boolean;
    overallExperinceRecommentQ4?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
};
export type ExcelOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "gender" | "age" | "region" | "department" | "empTenure" | "overallExperinceSatifyQ2" | "overallExperinceCompleteQ3" | "overallExperinceRecommentQ4" | "createdAt" | "updatedAt", ExtArgs["result"]["excel"]>;
export type $ExcelPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "Excel";
    objects: {};
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: number;
        gender: number;
        age: number;
        region: number;
        department: number;
        empTenure: number;
        overallExperinceSatifyQ2: number;
        overallExperinceCompleteQ3: number;
        overallExperinceRecommentQ4: number;
        createdAt: Date;
        updatedAt: Date;
    }, ExtArgs["result"]["excel"]>;
    composites: {};
};
export type ExcelGetPayload<S extends boolean | null | undefined | ExcelDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$ExcelPayload, S>;
export type ExcelCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<ExcelFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: ExcelCountAggregateInputType | true;
};
export interface ExcelDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['Excel'];
        meta: {
            name: 'Excel';
        };
    };
    /**
     * Find zero or one Excel that matches the filter.
     * @param {ExcelFindUniqueArgs} args - Arguments to find a Excel
     * @example
     * // Get one Excel
     * const excel = await prisma.excel.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ExcelFindUniqueArgs>(args: Prisma.SelectSubset<T, ExcelFindUniqueArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find one Excel that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ExcelFindUniqueOrThrowArgs} args - Arguments to find a Excel
     * @example
     * // Get one Excel
     * const excel = await prisma.excel.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ExcelFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, ExcelFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first Excel that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelFindFirstArgs} args - Arguments to find a Excel
     * @example
     * // Get one Excel
     * const excel = await prisma.excel.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ExcelFindFirstArgs>(args?: Prisma.SelectSubset<T, ExcelFindFirstArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first Excel that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelFindFirstOrThrowArgs} args - Arguments to find a Excel
     * @example
     * // Get one Excel
     * const excel = await prisma.excel.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ExcelFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, ExcelFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find zero or more Excels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Excels
     * const excels = await prisma.excel.findMany()
     *
     * // Get first 10 Excels
     * const excels = await prisma.excel.findMany({ take: 10 })
     *
     * // Only select the `id`
     * const excelWithIdOnly = await prisma.excel.findMany({ select: { id: true } })
     *
     */
    findMany<T extends ExcelFindManyArgs>(args?: Prisma.SelectSubset<T, ExcelFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    /**
     * Create a Excel.
     * @param {ExcelCreateArgs} args - Arguments to create a Excel.
     * @example
     * // Create one Excel
     * const Excel = await prisma.excel.create({
     *   data: {
     *     // ... data to create a Excel
     *   }
     * })
     *
     */
    create<T extends ExcelCreateArgs>(args: Prisma.SelectSubset<T, ExcelCreateArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Create many Excels.
     * @param {ExcelCreateManyArgs} args - Arguments to create many Excels.
     * @example
     * // Create many Excels
     * const excel = await prisma.excel.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     */
    createMany<T extends ExcelCreateManyArgs>(args?: Prisma.SelectSubset<T, ExcelCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Delete a Excel.
     * @param {ExcelDeleteArgs} args - Arguments to delete one Excel.
     * @example
     * // Delete one Excel
     * const Excel = await prisma.excel.delete({
     *   where: {
     *     // ... filter to delete one Excel
     *   }
     * })
     *
     */
    delete<T extends ExcelDeleteArgs>(args: Prisma.SelectSubset<T, ExcelDeleteArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Update one Excel.
     * @param {ExcelUpdateArgs} args - Arguments to update one Excel.
     * @example
     * // Update one Excel
     * const excel = await prisma.excel.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    update<T extends ExcelUpdateArgs>(args: Prisma.SelectSubset<T, ExcelUpdateArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Delete zero or more Excels.
     * @param {ExcelDeleteManyArgs} args - Arguments to filter Excels to delete.
     * @example
     * // Delete a few Excels
     * const { count } = await prisma.excel.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     *
     */
    deleteMany<T extends ExcelDeleteManyArgs>(args?: Prisma.SelectSubset<T, ExcelDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more Excels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Excels
     * const excel = await prisma.excel.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    updateMany<T extends ExcelUpdateManyArgs>(args: Prisma.SelectSubset<T, ExcelUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Create or update one Excel.
     * @param {ExcelUpsertArgs} args - Arguments to update or create a Excel.
     * @example
     * // Update or create a Excel
     * const excel = await prisma.excel.upsert({
     *   create: {
     *     // ... data to create a Excel
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Excel we want to update
     *   }
     * })
     */
    upsert<T extends ExcelUpsertArgs>(args: Prisma.SelectSubset<T, ExcelUpsertArgs<ExtArgs>>): Prisma.Prisma__ExcelClient<runtime.Types.Result.GetResult<Prisma.$ExcelPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Count the number of Excels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelCountArgs} args - Arguments to filter Excels to count.
     * @example
     * // Count the number of Excels
     * const count = await prisma.excel.count({
     *   where: {
     *     // ... the filter for the Excels we want to count
     *   }
     * })
    **/
    count<T extends ExcelCountArgs>(args?: Prisma.Subset<T, ExcelCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], ExcelCountAggregateOutputType> : number>;
    /**
     * Allows you to perform aggregations operations on a Excel.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ExcelAggregateArgs>(args: Prisma.Subset<T, ExcelAggregateArgs>): Prisma.PrismaPromise<GetExcelAggregateType<T>>;
    /**
     * Group by Excel.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExcelGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     *
    **/
    groupBy<T extends ExcelGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: ExcelGroupByArgs['orderBy'];
    } : {
        orderBy?: ExcelGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, ExcelGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetExcelGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    /**
     * Fields of the Excel model
     */
    readonly fields: ExcelFieldRefs;
}
/**
 * The delegate class that acts as a "Promise-like" for Excel.
 * Why is this prefixed with `Prisma__`?
 * Because we want to prevent naming conflicts as mentioned in
 * https://github.com/prisma/prisma-client-js/issues/707
 */
export interface Prisma__ExcelClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
/**
 * Fields of the Excel model
 */
export interface ExcelFieldRefs {
    readonly id: Prisma.FieldRef<"Excel", 'Int'>;
    readonly gender: Prisma.FieldRef<"Excel", 'Int'>;
    readonly age: Prisma.FieldRef<"Excel", 'Int'>;
    readonly region: Prisma.FieldRef<"Excel", 'Int'>;
    readonly department: Prisma.FieldRef<"Excel", 'Int'>;
    readonly empTenure: Prisma.FieldRef<"Excel", 'Int'>;
    readonly overallExperinceSatifyQ2: Prisma.FieldRef<"Excel", 'Int'>;
    readonly overallExperinceCompleteQ3: Prisma.FieldRef<"Excel", 'Int'>;
    readonly overallExperinceRecommentQ4: Prisma.FieldRef<"Excel", 'Int'>;
    readonly createdAt: Prisma.FieldRef<"Excel", 'DateTime'>;
    readonly updatedAt: Prisma.FieldRef<"Excel", 'DateTime'>;
}
/**
 * Excel findUnique
 */
export type ExcelFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * Filter, which Excel to fetch.
     */
    where: Prisma.ExcelWhereUniqueInput;
};
/**
 * Excel findUniqueOrThrow
 */
export type ExcelFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * Filter, which Excel to fetch.
     */
    where: Prisma.ExcelWhereUniqueInput;
};
/**
 * Excel findFirst
 */
export type ExcelFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * Filter, which Excel to fetch.
     */
    where?: Prisma.ExcelWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Excels to fetch.
     */
    orderBy?: Prisma.ExcelOrderByWithRelationInput | Prisma.ExcelOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for Excels.
     */
    cursor?: Prisma.ExcelWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Excels from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Excels.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of Excels.
     */
    distinct?: Prisma.ExcelScalarFieldEnum | Prisma.ExcelScalarFieldEnum[];
};
/**
 * Excel findFirstOrThrow
 */
export type ExcelFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * Filter, which Excel to fetch.
     */
    where?: Prisma.ExcelWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Excels to fetch.
     */
    orderBy?: Prisma.ExcelOrderByWithRelationInput | Prisma.ExcelOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for Excels.
     */
    cursor?: Prisma.ExcelWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Excels from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Excels.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of Excels.
     */
    distinct?: Prisma.ExcelScalarFieldEnum | Prisma.ExcelScalarFieldEnum[];
};
/**
 * Excel findMany
 */
export type ExcelFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * Filter, which Excels to fetch.
     */
    where?: Prisma.ExcelWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Excels to fetch.
     */
    orderBy?: Prisma.ExcelOrderByWithRelationInput | Prisma.ExcelOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for listing Excels.
     */
    cursor?: Prisma.ExcelWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Excels from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Excels.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of Excels.
     */
    distinct?: Prisma.ExcelScalarFieldEnum | Prisma.ExcelScalarFieldEnum[];
};
/**
 * Excel create
 */
export type ExcelCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * The data needed to create a Excel.
     */
    data: Prisma.XOR<Prisma.ExcelCreateInput, Prisma.ExcelUncheckedCreateInput>;
};
/**
 * Excel createMany
 */
export type ExcelCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to create many Excels.
     */
    data: Prisma.ExcelCreateManyInput | Prisma.ExcelCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * Excel update
 */
export type ExcelUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * The data needed to update a Excel.
     */
    data: Prisma.XOR<Prisma.ExcelUpdateInput, Prisma.ExcelUncheckedUpdateInput>;
    /**
     * Choose, which Excel to update.
     */
    where: Prisma.ExcelWhereUniqueInput;
};
/**
 * Excel updateMany
 */
export type ExcelUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to update Excels.
     */
    data: Prisma.XOR<Prisma.ExcelUpdateManyMutationInput, Prisma.ExcelUncheckedUpdateManyInput>;
    /**
     * Filter which Excels to update
     */
    where?: Prisma.ExcelWhereInput;
    /**
     * Limit how many Excels to update.
     */
    limit?: number;
};
/**
 * Excel upsert
 */
export type ExcelUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * The filter to search for the Excel to update in case it exists.
     */
    where: Prisma.ExcelWhereUniqueInput;
    /**
     * In case the Excel found by the `where` argument doesn't exist, create a new Excel with this data.
     */
    create: Prisma.XOR<Prisma.ExcelCreateInput, Prisma.ExcelUncheckedCreateInput>;
    /**
     * In case the Excel was found with the provided `where` argument, update it with this data.
     */
    update: Prisma.XOR<Prisma.ExcelUpdateInput, Prisma.ExcelUncheckedUpdateInput>;
};
/**
 * Excel delete
 */
export type ExcelDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
    /**
     * Filter which Excel to delete.
     */
    where: Prisma.ExcelWhereUniqueInput;
};
/**
 * Excel deleteMany
 */
export type ExcelDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which Excels to delete
     */
    where?: Prisma.ExcelWhereInput;
    /**
     * Limit how many Excels to delete.
     */
    limit?: number;
};
/**
 * Excel without action
 */
export type ExcelDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Excel
     */
    select?: Prisma.ExcelSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Excel
     */
    omit?: Prisma.ExcelOmit<ExtArgs> | null;
};
//# sourceMappingURL=Excel.d.ts.map